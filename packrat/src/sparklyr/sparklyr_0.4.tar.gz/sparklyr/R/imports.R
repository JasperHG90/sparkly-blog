#' @import methods
#' @import DBI
#' @import utils
#' @importFrom tibble data_frame
#' @importFrom stats as.formula coefficients gaussian na.omit predict quantile
NULL
